# Child LLM Assistant

Проект по созданию ассистента для детей на основе LLM.